from multiprocessing import context
from unicodedata import category
from django.shortcuts import redirect, render
from datetime import datetime
from myApp.models import Contact, CustomUser, Testimonial
from django.contrib import messages
from myApp.register import Reg
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
from django.core.mail import send_mail
from myProject import settings
from myApp.prof import Profile
from myApp.booking import Booking
import uuid
from myApp.forms import AccountUpdateForm, CustomUserChangeForm

# Create your views here.
def homepage(request):
    test = Testimonial.objects.all()
    context = {'testimonial': test}
    return render(request, 'homepage.html', context)


def about(request):
    return render(request, 'about.html')


def contact(request):
    if request.method == "POST":
        name=request.POST.get('name')
        email=request.POST.get('email')
        desc=request.POST.get('desc')
        category=request.POST.get('category')
        contact=Contact(name = name,email = email,desc = desc,category = category,date = datetime.today())
        contact.save()
        messages.success(request, 'Your form is submitted.')
        
        subject='STRETCH N SMILE'+ contact.name + 'Contact form Submission',
        message= "Details of  "+ contact.name + ",\n" + "The visitor provides the below details. \n \n "+ "Name:  "+ contact.name + ",\n"+ "Email:  "+ contact.email + ",\n"+"Category:  "+ contact.category + ",\n"+"Messages:  "+ contact.desc + ",\n"
        from_email=settings.EMAIL_HOST_USER
        to_list=['debanjan.majumdar@acespireconsulting.com' ]

        send_mail(subject,message,from_email,to_list,fail_silently=True,)

    return render(request, 'contact.html')


def sessions(request):
    if request.method == "POST":
        name=request.POST.get('name')
        email=request.POST.get('email')
        session=request.POST.get('session')
        mobilenumber=request.POST.get('mobilenumber')
        session=Booking(name = name,email = email,session = session,mobilenumber = mobilenumber,date = datetime.today())
        session.save()
        messages.success(request, 'Your form is submitted.')
        
        subject='Booking for '+ session.session + ' | Yoga Session | Stretch N Smile'
        message= "Details of  "+ session.name + ",\n" + "The visitor provides the below  booking details for Yoga Session . \n \n "+ "Name:  "+ session.name + ",\n"+ "Email:  "+ session.email + ",\n"+"Mobile No:  "+ session.mobilenumber + ",\n"+"Selected For:  "+ session.session + ",\n"
        from_email=settings.EMAIL_HOST_USER
        to_list=['debanjan.majumdar@acespireconsulting.com' ]
        send_mail(subject,message,from_email,to_list,fail_silently=True,)
    return render(request, 'sessions.html')


def workshop(request):
    if request.method == "POST":
        name=request.POST.get('name')
        email=request.POST.get('email')
        session=request.POST.get('session')
        mobilenumber=request.POST.get('mobilenumber')
        session=Booking(name = name,email = email,session = session,mobilenumber = mobilenumber,date = datetime.today())
        session.save()
        messages.success(request, 'Your form is submitted.')
        
        subject='Booking for '+ session.session + ' | Workshop | Stretch N Smile'
        message= "Details of  "+ session.name + ",\n" + "The visitor provides the below booking details for Workshop . \n \n "+ "Name:  "+ session.name + ",\n"+ "Email:  "+ session.email + ",\n"+"Mobile No:  "+ session.mobilenumber + ",\n"+"Selected For:  "+ session.session + ",\n"
        from_email=settings.EMAIL_HOST_USER
        to_list=['debanjan.majumdar@acespireconsulting.com' ]
        send_mail(subject,message,from_email,to_list,fail_silently=True,)
    return render(request, 'workshop.html')


def corporateworkshop(request):
    if request.method == "POST":
        name=request.POST.get('name')
        email=request.POST.get('email')
        session=request.POST.get('session')
        mobilenumber=request.POST.get('mobilenumber')
        session=Booking(name = name,email = email,session = session,mobilenumber = mobilenumber,date = datetime.today())
        session.save()
        messages.success(request, 'Your form is submitted.')
        
        subject='Booking for '+ session.session + ' | Corporate Workshop | Stretch N Smile'
        message= "Details of  "+ session.name + ",\n" + "The visitor provides the below details for Corporate Workshop . \n \n "+ "Name:  "+ session.name + ",\n"+ "Email:  "+ session.email + ",\n"+"Mobile No:  "+ session.mobilenumber + ",\n"+"Selected For:  "+ session.session + ",\n"
        from_email=settings.EMAIL_HOST_USER
        to_list=['debanjan.majumdar@acespireconsulting.com' ]
        send_mail(subject,message,from_email,to_list,fail_silently=True,)
    return render(request, 'corporateworkshop.html')


def blog(request):
    return render(request, 'blog.html')

def blog2(request):
    return render(request, 'blog2.html')    


def why_yoga(request):
    return render(request, 'why_yoga.html')


def authentic_yoga_tea_recipe(request):
    return render(request, 'authentic_yoga_tea_recipe.html')


def signin(request):
    if request.method=="POST":
        email=request.POST.get('email')
        password=request.POST.get('password')

        user=authenticate(email=email, password=password)
        if user is not None:
            login(request,user)
            name=user.first_name
            email=user.email
            messages.success(request,'You are successfully loged in')
            subject='Welcome to STRETCH N SMILE ,'
            message= "Welcome"+ name + ",\n" + "Test for login  you for joining Stretch and Smile. You are in for a journey to New You. You will find various courses to suit your specific needs. We believe in changing the whole lifestyle on this journey and we help you with this journey towards the Wholesome you.\n Keep Walking on this Journey.\nNamaste! \n \n regards & thank you, \n deepali \n Stretch and Smile Yoga."
            from_email=settings.EMAIL_HOST_USER
            to_list=[email]
            send_mail(subject,message,from_email,to_list,fail_silently=True,)
            
            return render(request,"profnew.html", {'name':name})
            

        else:
            messages.error(request,'You are not registered')    
            return render(request,'reg.html')

    return render(request,'login.html')


def reg(request):
     if request.method == "POST":
        first_name=request.POST.get('first_name')
        last_name=request.POST.get('last_name')
       # username=request.POST.get('username')
        email=request.POST.get('email')
        pswd1=request.POST.get('pswd1')
        pswd2=request.POST.get('pswd2')



        if pswd1 != pswd2 :
            messages.error(request,'Passwords doesnot match, try again')
            return  render(request,'reg.html')
        
        if  CustomUser.objects.filter(email=email).first():
          messages.error(request,' User already exist with this email id, Please try again with new email id')
          return  render(request,'reg.html')

        # if  CustomUser.objects.filter(username=username).first():
        #   messages.error(request,'User already exist with this username ,Please try again with new username')
        #   return  render(request,'reg.html')
 


        myuser=CustomUser.objects.create_user(email, pswd2,pswd1)
        myuser.first_name=first_name
        myuser.last_name=last_name
        #myuser.username=username
        myuser.email=email
        myuser.save()

        profile_obj=Profile.objects.create(user=myuser)
        profile_obj.save()

        messages.success(request,'You are successfully registired')
        
        # subject='Welcome to STRETCH N SMILE ,'
        # message= "Welcome"+ myuser.first_name + ",\n" + "Thank you for joining Stretch and Smile. You are in for a journey to New You. You will find various courses to suit your specific needs. We believe in changing the whole lifestyle on this journey and we help you with this journey towards the Wholesome you.\n Keep Walking on this Journey.\nNamaste! \n \n regards & thank you, \n deepali \n Stretch and Smile Yoga."
        # from_email=settings.EMAIL_HOST_USER
        # to_list=[myuser.email]
        # send_mail(subject,message,from_email,to_list,fail_silently=True,)

        return redirect('login')
  
     return render(request, 'reg.html')

def forgetpw(request):
    try:
        if request.method =='POST':
            email=request.POST.get('email')

            if not CustomUser.objects.filter(email=email).first():
              messages.error(request,'Passwords doesnot match, try again')
              return  render(request,'reg.html')

            myuser=CustomUser.objects.get(email=email)
            token= str (uuid.uuid4())
            profile_obj=Profile.objects.get(user=myuser)
            profile_obj.forget_password_token=token
            profile_obj.save()

            subject='Forgot password link'
            message=f'Hi click on the link to change reset password https://stretchandsmileyoga.com/changepw/{token}/'
            from_email=settings.EMAIL_HOST_USER
            to_list=[email]
            send_mail(subject,message,from_email,to_list,fail_silently=True,)
            # return True
            #send_forget_password_mail(myuser,token)
            messages.success(request, 'Email sent to your mail id .')
            return render(request, 'forgetpw.html')


    except Exception as e:
          print(e)
    return render(request, 'forgetpw.html') 


def signout(request):
    logout(request)
    messages.success(request,'You are logged out')
    return render(request,'homepage.html')


def changepw(request,token):
    context={}
    try:
        profile_obj=Profile.objects.filter(forget_password_token=token).first()

        context={'user_id':profile_obj.user_id}
         
        if request.method=='POST':
            pswd1=request.POST.get('pswd1')
            pswd2=request.POST.get('pswd2')
            user_id=request.POST.get('user_id')

            if user_id is None:
              messages.error(request,'User doesnot found, try again')
              return render(request, 'changepw.html')
  

            if pswd1!= pswd2 :
               messages.error(request,'Passwords doesnot match, try again')
               return render(request, 'changepw.html')
  


            myuser=CustomUser.objects.get(id=user_id)   
            myuser.set_password(pswd1) 
            myuser.save()
            messages.success(request,'Your password successfully changed')
            return redirect( 'login')
  



        #print(pswd1)
        #print(f'name:{profile_obj}')
          
        
        context={'user_id':profile_obj.user_id}


    except Exception as e:
        print(e)
    return render(request, 'changepw.html',context)

    
    



def profile(request):
     return render(request, 'profnew.html')    


def editprofile(request):
    context={}
    try:
        if request.method =='POST':
    
         u_form=CustomUserChangeForm(request.POST,instance=request.user)
         p_form=AccountUpdateForm(request.POST,request.FILES,instance=request.user.account)

         if u_form.is_valid and p_form.is_valid:
          u_form.save()
          p_form.save()
          messages.success(request,'Your profile is successfully updated')
          return render(request, 'profnew.html') 

       



        else:
           u_form=CustomUserChangeForm(request.POST,instance=request.user)
           p_form=AccountUpdateForm(request.POST,instance=request.user.account)

        context={'u_form':u_form,'p_form':p_form}
    except :
        
        messages.error(request,'Your profile is not updated ,please enter the valid fields')

    return render(request, 'profile.html', context)
     

