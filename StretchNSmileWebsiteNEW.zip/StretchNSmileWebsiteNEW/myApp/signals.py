from django.db.models.signals import post_save
from myApp.models import CustomUser
from django.dispatch import receiver
from myApp.acc import Account
from myApp.models import CustomUser

@receiver(post_save,sender=CustomUser)
def create_account(sender,instance,created,**kwargs):
    if created:
        Account.objects.create(user=instance)



@receiver(post_save,sender=CustomUser)
def save_account(sender,instance,**kwargs):
    instance.account.save()
   
