from django.contrib import admin
from myApp.models import Contact, Testimonial
from myApp.register import Reg
from myApp.prof import Profile
from myApp.acc import Account
from .models import CustomUser
from django.contrib.auth.admin import UserAdmin
from myApp.booking import Booking


class CustomUserAdmin(UserAdmin):
    model = CustomUser
    list_display = ['email', 'username']


# Register your models here.
admin.site.register(CustomUser, CustomUserAdmin)

admin.site.register(Contact)

admin.site.register(Reg)

admin.site.register(Testimonial)

admin.site.register(Profile)


admin.site.register(Account)


admin.site.register(Booking)