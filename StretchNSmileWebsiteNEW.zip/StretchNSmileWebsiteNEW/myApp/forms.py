from django.forms import ModelForm
from django.contrib.auth .models import User
from django.contrib.auth.forms import UserChangeForm
from myApp.acc import Account
from .models import CustomUser
            
class AccountUpdateForm(ModelForm):    
    class Meta:
        model=Account
        fields=['title','phone','organization','image']


class CustomUserChangeForm(ModelForm):
    class Meta:
        model = CustomUser
        fields = ['email','first_name','last_name']

        
