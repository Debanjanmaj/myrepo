from django.db import models

# Create your models here.
class Booking(models.Model):
    name = models.CharField(max_length=130)
    email = models.CharField(max_length=130)
    session = models.CharField(max_length=130)
    mobilenumber = models.IntegerField()
    date = models.DateField()

    def __str__(self):
      return self.name