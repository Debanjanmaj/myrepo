from django.db import models
from django.core.validators import RegexValidator

from myApp.models import CustomUser

class Account(models.Model):
  user=models.OneToOneField(CustomUser,on_delete=models.CASCADE, null=True, blank=True)
  image=models.ImageField(default='default.jpg',upload_to='media/profile_pics')
  phoneNumberRegex = RegexValidator(regex = r"^\+?1?\d{8,15}$")
  phone=models.CharField(validators = [phoneNumberRegex],max_length = 13, null=True, blank=True)
  organization=models.CharField(max_length=130, blank=True)
  title=models.CharField(max_length=130, blank=True)

  def __str__(self):
    return  self.user.username
