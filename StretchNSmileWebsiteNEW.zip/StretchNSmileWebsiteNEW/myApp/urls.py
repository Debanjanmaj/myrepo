from django.urls import path

from myApp import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', views.homepage, name='homepage'),
    path('homepage', views.homepage, name='homepage'),
    path('about', views.about, name='about'),
    path('contact', views.contact, name='contact'),
    path('sessions', views.sessions, name='sessions'),
    path('workshop', views.workshop, name='workshop'),
    path('corporateworkshop', views.corporateworkshop, name='corporateworkshop'),
    path('blog', views.blog, name='blog'),
    path('blog2', views.blog2, name='blog2'),
    path('authentic_yoga_tea_recipe', views.authentic_yoga_tea_recipe, name='authentic_yoga_tea_recipe'),
    path('why_yoga', views.why_yoga, name='why_yoga'),
    path('login', views.signin, name='login'),
    path('reg', views.reg, name='reg'),
    path('forgetpw', views.forgetpw, name='forgetpw'),
    path('signout', views.signout, name='signout'),
    path('profile', views.profile, name='profile'),
    path('edit-profile', views.editprofile, name='edit-profile'),
    path('changepw/<token>/', views.changepw, name='changepw'),
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
