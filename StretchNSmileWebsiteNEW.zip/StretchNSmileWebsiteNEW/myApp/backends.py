# from django.contrib.auth.backends import BaseBackend
from django.contrib.auth.base_user import BaseUserManager
from django.contrib.auth.models import User
from django.contrib.auth.backends import BaseBackend

from myApp.models import CustomUser

class MyBackend(BaseBackend):

    def authenticate(self, request, email=None, password=None):
        try:
            user = CustomUser.objects.get(email=email)
        except User.DoesNotExist:
            return None

        if user is not None and user.check_password(password):
                return user

        return super().authenticate(request, **kwargs)


class UserManager(BaseUserManager):

    def create_user(self, username, email, password=None):
        if not email:
            raise ValueError('user must have email')
        if not username:
            raise ValueError('must have username')

        user = self.create_user(
            email=self.normalize_email(email),
            username=username,
        )

        user.set_password(password)
        user.save(using=self._db)
        return user


    def create_superuser(self, username=None, email=None, password=None):
        user = self.create_user(
        username=username,
        email=email,
        password=password,

        )
        user.is_admin =True
        user.is_staff =True
        user.is_superuser=True
        user.save(using=self._db)
        return user




