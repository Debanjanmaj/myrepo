var attempt = 3; // Variable to count number of attempts.
    // Below function Executes on click of login button.
    function validate(){
    var username = document.getElementById("InputEmail1").value;
    var password = document.getElementById("Password1").value;
    if ( username == "deba" && password == "deba123")
    {
    alert ("Login successfully");
    window.location = 'about'; // Redirecting to other page.
    return false;
    }
    else
    {
    attempt --;// Decrementing by one.
    alert("You have left "+attempt+" attempt;");
    // Disabling fields after 3 attempts.
    if( attempt == 0){
    document.getElementById("InputEmail1").disabled = true;
    document.getElementById("Password1").disabled = true;
    document.getElementById("submit").disabled = true;
    return false;
    }
    }
    }