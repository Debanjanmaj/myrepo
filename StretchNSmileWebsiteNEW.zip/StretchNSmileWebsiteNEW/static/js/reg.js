function matchPassword()
 {
    var pw1 = document.getElementById("pswd1").value;
    var pw2 = document.getElementById("pswd2").value;
    if(pw1 != pw2)
    {
      alert("Passwords did not match");

    }
   else
   {
      alert("Password created successfully");
      window.location = 'login';
      return true;
   }
 }

